<?php
$name = $_POST['name'];
$age  = $_POST['age'];
$gender = $_POST['gender'];
$Locality = $_POST['Locality'];
$Email = $_POST['Email'];
$num = $_POST['num'];

$conn = new mysqli('localhost','root','','gym_data');
if($conn->connect_error)
{
    die('connection failed :' .$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into gym(Name,Age,Gender,Locality,Email_id,Phone_No)values(?,?,?,?,?,?)");
    $stmt->bind_param("sssssi",$name,$age,$gender,$Locality,$Email,$num);
    $stmt->execute();
    echo" <h1>Register successfully...<h1>";
    $stmt->close();
    $conn->close();
}
?>